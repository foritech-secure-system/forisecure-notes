# Session Summary

- **Контекст:** Sync на `forisecure-notes`; валидиране срещу наличното repo; подготовка за EU програми (DEP Cyber PQC PKI, Horizon C3), NGI Zero вече подадено.
- **Решения:** NFT се използва само като *user badge / license marker* (не за security); core = PQC PKI (Kyber/Dilithium) + DID/SSI + Zero‑Knowledge auth; модулна структура Classic/Web3/PQC.
- **Действия днес:** Генерирани архитектурна схема (PNG) и DOCX, проектен шаблон (DOCX), определени крайни срокове (DEP 7 Oct 2025, Horizon C3 12 Nov 2025).
- **Рискове/блокери:** TRL за DEP трябва да е 7–8 (нужно MVP + пилот); съфинансиране ~30% по DEP; нужни партньори за Horizon (мин. 3 държави).
- **Следващи стъпки:** (1) TRL7 чеклист; (2) PQC PKI MVP демо и пилот; (3) Call‑alignment документ; (4) Подготовка на DEP пакет; (5) Партньорско търсене за Horizon.

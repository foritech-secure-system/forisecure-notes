# Changes vs. previous sync

- Добавени са: Session Summary, планови таблици (Backlog/Decisions), Delivery бележки (DNS/Security/Tasks_Today), TRL7 чеклист, дневен CHANGELOG.
- Не са променяни съществуващи файлове в repo; пакетът е само за локален синк.

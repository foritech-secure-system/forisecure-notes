# Decisions (log)

- 2025-09-11: NFT се използва само като визуален badge/license marker (без роля в сигурността).
- 2025-09-11: Архитектурата по подразбиране: PQC PKI + DID/SSI + Zero‑Knowledge auth; модулност Classic/Web3/PQC.
- 2025-09-11: Целим DEP Cyber (PQC PKI) и Horizon C3; NGI Zero вече подадено.

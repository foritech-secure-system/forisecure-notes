# Backlog

| Item | Priority (1-3) | Owner | Status (TODO/DOING/DONE) | Due |
|---|---|---|---|---|
| PQC PKI MVP (hybrid X.509, Kyber/Dilithium) | 1 | forrybg | TODO | 2025-09-25 |
| ZK Verifier microservice (Auth Gateway) | 1 | forrybg | TODO | 2025-09-22 |
| Call-Alignment doc (DEP/Horizon mapping) | 2 | assistant | TODO | 2025-09-18 |
| Pilot candidate outreach (1–2 SMEs) | 2 | forrybg | TODO | 2025-09-20 |
| SIEM ingest (Wazuh/Suricata) minimal | 2 | forrybg | TODO | 2025-09-24 |
| DEP package skeleton (forms, budget) | 1 | assistant | TODO | 2025-09-26 |

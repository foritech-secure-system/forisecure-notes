# TRL7 Readiness – Checklist

- [ ] PQC PKI MVP (hybrid TLS certs, issuance/verify, rotation)
- [ ] ZK Verifier (proof verify → short-lived session)
- [ ] Pilot deployment (1–2 SMEs) – signed LoI
- [ ] SIEM ingest with alerts (Wazuh/Suricata minimal)
- [ ] Ops runbook + security baseline (13+2)
- [ ] Demo recording/screenshots + KPI
Links:
- Repo (notes): https://github.com/foritech-secure-system/forisecure-notes
- Core repo(s): (private) – refer to internal docs

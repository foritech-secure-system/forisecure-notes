# DNS / Infra (summary)

> Без секрети. Потвърди стойности преди промяна в продукция.

| Domain | Type | Name/Host | Value | Notes |
|---|---|---|---|---|
| forisecure.com | CNAME | forisecure-notes | foritech-secure-system.github.io | GitHub Pages (CNAME в repo) – валидация |
| forisec.eu | A/AAAA | @ | TBD | Продвайдър/зона за потвърждение |
| forisecure.com | TXT | `_github-pages-challenge-...` | TBD | Само ако изискано за верификация |
| forisecure.com | TXT | `_acme-challenge` | (managed by TLS issuer) | Ако се ползва ACME DNS-01 |

# Tasks Today

- Преглед на repo структурата и наличните артефакти (README, TASKS, EVIDENCE, SYNC_MANIFEST).
- Съставяне на архитектурна схема (PNG) + DOCX за PQC + DID/SSI + ZK.
- Изготвен шаблон на проектно предложение (DOCX).
- Консолидация на крайни срокове: DEP Cyber (7 Oct 2025), Horizon C3 (12 Nov 2025).
- Подготвен този синк пакет (ZIP).

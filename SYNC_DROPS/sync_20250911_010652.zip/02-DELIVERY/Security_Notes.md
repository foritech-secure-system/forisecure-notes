# Security Notes

- DNSSEC: Проверка и активиране при регистратора (ако е налично).
- HTTPS enforce: Активирай HSTS (includeSubDomains, preload – след тестване).
- Git hygiene: `.gitignore` за ключове/токени е активиран в repo; забрана за комит на секрети.
- SIEM: Централизиран ingest от VPN, Auth Gateway, Storage.
- MFA: Изисквай MFA за всички административни достъпи.

## 2025-09-11 — SYNC package drop
- Added structured notes package (session summary, changes, planning, delivery, TRL-7 evidence).
- Documented current SSH/UFW/fail2ban/backup status and open restore action.
- No secrets included; all sensitive values redacted or omitted.

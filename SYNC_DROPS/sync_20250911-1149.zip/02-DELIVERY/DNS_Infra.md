# DNS / Infra
Currently **not in scope** for this sprint. Placeholder retained for future base domain / records plan.

# Tasks Today
- ✅ Verified SSH 8022 with key (ED25519 SHA256: liLXBX…).
- ✅ Verified rescue 2022 with password; SFTP enabled and tested (`scp -O` no longer needed).
- ✅ Pulled/verified backups; SHA256 OK; restore matrix prepared (PBKDF2/MD5).
- ✅ UFW + fail2ban status green; banned IPs recorded earlier.
- ✅ Timezone set; backup timer scheduled to 03:15 EEST.
- ☐ Finalize restore command once KDF confirmed.

# Changelog (2025-09-11)

- Seeded sync scaffolding for notes/planning/evidence (no secrets).
- Added DNS/TLS/security policy stubs to be filled with real data.
- Established simple backlog/decisions templates for weekly cadence.

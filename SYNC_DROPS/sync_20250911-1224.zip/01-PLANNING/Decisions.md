# Decisions

- 2025-09-05: Notes repo stays **no-secrets**; only planning/evidence/ops docs allowed.
- 2025-09-05: Single SME focus; Web3/NFT licensing to be captured as separate ADR when architecture stabilizes.
- 2025-09-05: TRL target ≥7; maintain evidence checklist per milestone.

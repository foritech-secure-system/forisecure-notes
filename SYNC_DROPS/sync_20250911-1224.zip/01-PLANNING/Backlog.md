# Backlog

| Item | Priority (1-3) | Owner | Status (TODO/DOING/DONE) | Due |
|------|-----------------|-------|--------------------------|-----|
| Stand up clean notes repo structure & commit | 1 | forrybg | DOING | YYYY-MM-DD |
| Document DNS records & HTTPS policy | 1 | forrybg | TODO | YYYY-MM-DD |
| Add simple CI (markdown lint/link check) | 2 | assistant→PR | TODO | YYYY-MM-DD |
| Capture TRL/KPI evidence links/screens | 1 | forrybg | TODO | YYYY-MM-DD |
| Weekly checkpoint (Saturday 10:00) | 2 | forrybg | TODO | YYYY-MM-DD |

## Changes since previous package
- Initial sync package for this chat thread (starter scaffolding). If you already had files, keep them; merge content as needed.

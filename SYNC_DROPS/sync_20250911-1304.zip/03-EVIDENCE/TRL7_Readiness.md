# TRL7_Readiness

**Goal**: TRL‑7 demo of hybrid X.509 (Kyber + Dilithium) in operational environment, with A/B pilots.

**KPIs**
- ≥2 pilots (A/B), ≥100 interop runs, ≥1 reproducible bundle, ≥1 screencast.

**Proof Artifacts**
- Repos & tags, CI logs, interop matrix, rotation playbooks, baseline 13+2 status.

**Status**
- Funding submissions done (NLnet + DIGITAL-ECCC).
- Evidence Binder: to be filled.

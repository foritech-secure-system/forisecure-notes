# CHANGELOG

## 2025-09-11
- Init sync packet with funding submissions (NLnet + DIGITAL-ECCC PUBLICPQC).

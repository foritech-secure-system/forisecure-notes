# 02_Changes

- Added **NLnet (Commons Fund)** submission entry (code **2025-10-218**).
- Added **DIGITAL-ECCC-2025-DEPLOY-CYBER-08 (PUBLICPQC)** submission entry:
  - Proposal ID **101285505**, Acronym **FPQCX509-TRL7**, duration 6 months, total €80,999, EU 50% €40,499.50.
- Created this sync packet (manifest + planning + delivery + evidence skeleton).

# Backlog

- Evidence Binder: repo links, tags, reproducible script, checksums.
- Interop test matrix: >=100 runs (ACME/CT/CR helpers included).
- Pilot A/B: rotation playbooks + logs.
- Docs site refresh (English), badges in README.
- Funding tracker: follow-ups + timeline.

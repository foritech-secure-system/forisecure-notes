# Decisions

- Architecture: PQC-first X.509 (Hybrid ML-KEM/Kyber + Dilithium), DID/SSI optional, ZK login optional.
- Repos: foritech-secure-system (core/private), foritech-investor-demo (docs/site), forisecure-notes (notes).
- Funding path: NLnet microgrant + DIGITAL-ECCC PUBLICPQC pilot.
- Process: GitHub Actions daily digest → docs/PROGRESS.md; Conventional Commits; CHANGELOG automation.

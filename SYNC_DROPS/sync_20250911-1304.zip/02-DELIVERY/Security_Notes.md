# Security_Notes (13+2 baseline)

- SFTP: planned
- Fail2Ban: planned
- UFW: planned
- TLS hardening: in scope (OQS/OpenSSL + hybrid profiles)
- Docs: ongoing
Note: run the baseline immediately after closing v0.5.2.

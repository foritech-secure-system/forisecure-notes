# Tasks_Today

- Save this sync ZIP to the server at: ~/sync_zips/
- Start Evidence Binder skeleton (03-EVIDENCE).
- Prepare minimal reproducible release script (bundle + hashes).

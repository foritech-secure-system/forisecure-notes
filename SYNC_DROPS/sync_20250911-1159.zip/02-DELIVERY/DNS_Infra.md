# DNS / Infra Notes
Текущо няма външен публичен endpoint за `foritech-secure-system`. 
DNS за `forisec.eu` / `forisecure.com` ще се добави при подготовка на публични услуги.
*За сега оставете като TBD.*

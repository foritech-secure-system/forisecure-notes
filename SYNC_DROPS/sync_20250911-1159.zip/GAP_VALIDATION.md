# Gap validation vs repo
- Repo вече съдържа: README.md, CHANGELOG.md, SYNC_MANIFEST.txt, INBOX, TASKS/BACKLOG.md, EVIDENCE, SYNC_DROPS.
- Този пакет НЕ дублира съществуващи файлове от repo; добавя компактни артефакти: Session summary/changes, текущ Backlog snapshot,
  Decisions, Delivery notes (DNS/Security/Tasks today), TRL7 чеклист и дневен CHANGELOG за локален sync.
- Няма секрети; всички чувствителни стойности са опуснати.

| Item | Priority | Owner | Status | Due |
|---|---|---|---|---|
| Lock liboqs/pyoqs versions & wheels cache | 1 | assistant | TODO |  |
| GPU CI runner (self-hosted) for smoke & selected tests | 1 | forrybg | TODO |  |
| Secrets policy: move keys to vault + SOPS rules | 1 | forrybg | DOING |  |
| docker-compose: slim dev image & reproducible venv | 2 | assistant | DOING |  |
| CLI UX: stable `--version` & `--help` across builds | 2 | assistant | DONE |  |
| Docs: onboarding.md for devs (GPU + docker) | 2 | assistant | TODO |  |
| Monitoring stack: Prometheus/Grafana minimal | 3 | forrybg | TODO |  |
| Key mgmt: FORITECH_SK loader & checks | 2 | assistant | DOING |  |

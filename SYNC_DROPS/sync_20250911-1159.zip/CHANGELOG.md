# Changelog — 2025-09-11
- GPU Docker runtime конфигуриран; `nvidia-smi` OK в контейнер.
- Smoke тестове зелени; добавени sanity тестове за CLI version/help и SPKI self-signed.
- Документен sync пакет генериран (този ZIP).

# Backlog

| Item | Priority (1-3) | Owner | Status | Due |
|---|---:|---|---|---|
| CI smoke тестове (GPU offload optional) | 2 | forrybg | TODO |  |
| SOP за управление на ключове (Kyber, X.509 SPKI) | 2 | forrybg | TODO |  |
| DNS записите за *forisec.eu* и *forisecure.com* | 1 | forrybg | DOING |  |
| .gitignore правила за секрети (унифицирани) | 1 | assistant | DONE |  |
| Мониторинг базов (Prometheus/Grafana минимално) | 3 | assistant | TODO |  |
| Докер образи: reproducible build бележки | 2 | assistant | TODO |  |

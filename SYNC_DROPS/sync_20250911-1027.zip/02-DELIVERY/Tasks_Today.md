# Tasks Today

- Ubuntu 24.04 + драйвери (NVIDIA 570.169), Docker + GPU runtime.
- CUDA smoke тестове вътре в контейнерите — OK.
- Dev контейнер `dev` с headless entrypoint; `venv` вътре + editable install на `foritech`.
- `liboqs-python` build + Kyber768 наличие потвърдено; генерирани Kyber ключове.
- Подготвен skeleton за DNS/безопасност/планиране в този пакет.

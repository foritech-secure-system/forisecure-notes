# Backlog

| Item | Priority (1-3) | Owner | Status | Due |
|---|---:|---|---|---|
| Publish GitHub Pages link in README | 2 | forrybg | TODO | — |
| Fill DNS records for custom domain (optional) | 2 | forrybg | TODO | — |
| Enable CodeQL in repo settings | 2 | forrybg | TODO | — |
| Add CI badge to README | 3 | assistant | TODO | — |
| Weekly TRL evidence update | 2 | forrybg | DOING | Sat |

# Decisions

- 2025-09-10: Use ZIP-only stubs to avoid duplication; keep repo minimal.

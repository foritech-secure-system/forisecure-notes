# Changelog

- 2025-09-10: Added planning/delivery stubs and TRL7 checklist (ZIP-only).

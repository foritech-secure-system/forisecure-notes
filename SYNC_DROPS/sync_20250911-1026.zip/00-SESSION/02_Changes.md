# Changes vs previous package

- Added planning stubs (`01-PLANNING/*`) to complement existing `TASKS/`.
- Added delivery stubs (`02-DELIVERY/*`) for DNS/HTTPS hardening notes.
- Added TRL7 readiness checklist under `03-EVIDENCE/` (links back to repo pages).
